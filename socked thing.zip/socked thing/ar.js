const config = require("./config.json")
const hasher = require("./hasher.js")
module.exports = (function () {
    var route = require('express').Router();

    route.use('/', function (req, res, next) {
        res.send("test")
        res.end()
    });
    return route;
})();