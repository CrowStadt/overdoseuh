const express = require("express")
const path = require('path');
const app = express()
require('dotenv').config();
const session = require('express-session')
const uuid = require('uuid').v4
const api_router = require("./api_router.js")
const body_parser = require('body-parser')
const http = require('http');
const server = http.createServer(app);
const { Server } = require("socket.io");
const io = new Server(server);
const authed_api = require('./ar.js')
const port = process.env.PORT

io.on("connection", (socket) => {
    console.log("cum")
})

app.use(session({
    genid: (req) => {
        return uuid()
    },
    secret: 'feline fanatics',
    resave: false,
    saveUninitialized: true
}))
app.use(body_parser.urlencoded({ extended: false }))

app.use(body_parser.json())

app.set('view engine', 'ejs');

app.engine('html', require('ejs').renderFile);

app.use((req, res, next) => {
    next()
})
app.use("/api", api_router)

app.use("/", (req, res, next) => {
    if (!req.session.loginstat) return res.render(__dirname + '/static/login.html', { failed: false, error_msg: undefined })
    return next()
})

app.use('/', authed_api)

app.use(express.static('static'));

app.listen(process.env.PORT || 80, function () {
    console.log('\x1b[36m%s\x1b[0m', `Alright there we go ! We are up on port: ${process.env.PORT || 80}`)
})