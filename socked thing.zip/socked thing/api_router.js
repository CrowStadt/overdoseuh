const config = require("./config.json")
const hasher = require("./hasher.js")
module.exports = (function () {
    var route = require('express').Router();

    route.use('/status', function (req, res, next) {
        res.send({ status: 200, uptime: process.uptime })
        res.end()
    });

    route.post('/login', function (req, res, next) {
        if (!config) return console.log("Fuck")
        if (!req.body.pass_at) return res.render(__dirname + '/static/login.html', { failed: true, error_msg: "Something went wrong please enter something valid" })
        if (req.body.pass_at.lengh < 2) return res.render(__dirname + '/static/login.html', { failed: true, error_msg: "Something went wrong please enter something valid" })

        const pass = hasher(req.body.pass_at)

        const eg_pass = hasher(config.pass)

        if (pass == eg_pass) {
            req.session.loginstat = true
            return next()
        }
        return res.render(__dirname + '/static/login.html', { failed: true, error_msg: "Wrong password" })
    })
    return route;
})();